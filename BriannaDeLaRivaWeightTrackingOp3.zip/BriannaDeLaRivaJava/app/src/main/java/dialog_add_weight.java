import android.app.AlertDialog;
        import android.content.Context;
        import android.content.DialogInterface;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.widget.EditText;
        import androidx.annotation.NonNull;

import com.example.briannadelarivajava.R;

public class dialog_add_weight {

    public static void show(@NonNull Context context, @NonNull final OnWeightEnteredListener listener) {
        // Create an alert dialog with an input field
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Add Weight");

        // Inflate the layout for the dialog
        View viewInflated = LayoutInflater.from(context).inflate(R.layout.dialog_add_weight, null);

        // Set up the input field
        final EditText input = viewInflated.findViewById(R.id.editTextWeight);
        builder.setView(viewInflated);

        // Set up the positive button click listener
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String enteredWeight = input.getText().toString().trim();
                if (!enteredWeight.isEmpty()) {
                    listener.onWeightEntered(enteredWeight);
                }
                dialog.dismiss();
            }
        });



        // Set up the cancel button click listener
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        // Show the dialog
        builder.show();
    }

    public interface OnWeightEnteredListener {
        void onWeightEntered(String weight);
    }
}
