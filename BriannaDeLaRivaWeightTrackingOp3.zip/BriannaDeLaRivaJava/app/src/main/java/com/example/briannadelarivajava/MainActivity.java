package com.example.briannadelarivajava;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import android.widget.Button;

import android.widget.EditText;

import android.widget.TextView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    EditText nameText;
    Button buttonLogIn;
    TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializing the views below
        nameText = findViewById(R.id.password);
        buttonLogIn = findViewById(R.id.buttonLogIn);
//        textGreeting = findViewById(R.id.textGreeting);

        ///set a TextWatcher to enable/disable the buttonSayHello button
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                // enable or disables the button based upon if there is text within the nameText
                buttonLogIn.setEnabled(!editable.toString().isEmpty());

            }
        });

        //setting a click listener for the button
        buttonLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, MainActivityTwo.class));

                LogIn(view);
            }
        });

    }
    // function for displaying a greeting
    public void LogIn(View view){
//        /// check if nameText is not null
//        if (nameText != null){
//            String name = nameText.getText().toString();
//            //check if the name is not empty
//            if (!name.isEmpty()) {
//                String greeting = "Hello " + name + "!";
//                textGreeting.setText(greeting);
//
//            } else {
//                /// handle the case when the name is empty
//                textGreeting.setText("You must enter name.");
            }
//        }
//
//    }
}
