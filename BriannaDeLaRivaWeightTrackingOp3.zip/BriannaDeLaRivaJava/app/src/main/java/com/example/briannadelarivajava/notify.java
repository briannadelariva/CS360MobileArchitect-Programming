package com.example.briannadelarivajava;

        import android.app.Activity;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.TextView;

public class notify extends Activity {

    private TextView notificationText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.after_login_screen);

        notificationText = findViewById(R.id.notificationText);

        Button smsButton = findViewById(R.id.smsButton);
        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showNotificationMessage();
            }
        });
    }

    private void showNotificationMessage() {
        notificationText.setText("Do you want to receive SMS notifications?");
    }
}
