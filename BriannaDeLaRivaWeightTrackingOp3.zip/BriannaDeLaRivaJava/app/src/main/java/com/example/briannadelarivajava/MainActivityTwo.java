package com.example.briannadelarivajava;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;
import android.view.View;
import android.widget.Button;



import androidx.appcompat.app.AppCompatActivity;

public class MainActivityTwo extends AppCompatActivity {

    private GridView gridView;
    private Button addButton;
    private CustomGridAdapter customGridAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.after_login_screen);

        gridView = findViewById(R.id.gridView);
        addButton = findViewById(R.id.addButton);

        customGridAdapter = new CustomGridAdapter();
        gridView.setAdapter(customGridAdapter);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeightToGrid();
            }
        });

        Button smsButton = findViewById(R.id.smsButton);

        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //  runs when the button is clicked
                Intent intent = new Intent(MainActivityTwo.this, notify.class);
                startActivity(intent);
            }
        });

    }

    private void addWeightToGrid() {
        customGridAdapter.addWeight("Add Weight " + (customGridAdapter.getCount() + 1));
        customGridAdapter.notifyDataSetChanged();
    }

    private class CustomGridAdapter extends BaseAdapter {

        private String[] weights;

        CustomGridAdapter() {
            weights = new String[0]; // Initial empty weights
        }

        @Override
        public int getCount() {
            return weights.length;
        }

        @Override
        public Object getItem(int position) {
            return weights[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView textView;
            LinearLayout layout;
            if (convertView == null) {
                // If convertView is null, inflate a new TextView
                textView = new TextView(MainActivityTwo.this);
                textView.setLayoutParams(new GridView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                textView.setPadding(16, 16, 16, 16);
            } else {
                {
                    // If convertView is not null, reuse it
                    textView = (TextView) convertView;
                }

                // Set the text for the TextView
                textView.setText(weights[position]);

            }
            return textView;
        }

        // Method to add new weight to the adapter
        public void addWeight(String newWeight){
            String[] newWeightArray = new String[weights.length + 1];
            System.arraycopy(weights, 0, newWeightArray, 0, weights.length);
            newWeightArray[weights.length] = newWeight;
            weights = newWeightArray;
        }

    }
}